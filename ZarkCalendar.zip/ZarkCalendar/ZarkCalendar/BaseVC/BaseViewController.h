

/********************** call me Jack, or Zark *************************/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UINavigationController

@end

NS_ASSUME_NONNULL_END
