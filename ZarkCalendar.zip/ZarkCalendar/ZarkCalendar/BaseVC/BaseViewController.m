

/********************** call me Jack, or Zark *************************/

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     [self setupNavigation];
}

- (void)setupNavigation {
    
    self.navigationBar.barTintColor = [UIColor whiteColor];      //背景色
    //去掉nav bar下面分割线
    self.navigationBar.shadowImage = [UIImage new];
    self.navigationBar.tintColor = [UIColor blackColor];    //返回按钮字体颜色
    self.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor blackColor], NSFontAttributeName: [UIFont systemFontOfSize:15]};
    self.navigationBar.translucent = NO;
    
}

@end
