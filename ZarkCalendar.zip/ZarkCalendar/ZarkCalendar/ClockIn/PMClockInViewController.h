

/********************** call me Jack, or Zark *************************/


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PMClockInViewController : UIViewController

//上、下班打卡key
+ (NSString *)getClockinKey;

+ (NSString *)todyClockinValue: (BOOL)isOnDuty;

@end

NS_ASSUME_NONNULL_END
