

/********************** call me Jack, or Zark *************************/


#import "PMClockinRecordsViewController.h"
#import "PMMonthView.h"
#import "JKCalendar.h"
#import "PMClockinRecordsFooterView.h"
#import "TheMarcro.h"

@interface PMClockinRecordsViewController ()<UIScrollViewDelegate> {
    
    UIScrollView *_scrollView;
    UIView *_footerView;
    PMClockinRecordsFooterView *_footerContentView;
    
    PMMonthView *_monthView1, *_monthView2, *_monthView3;
    CGFloat _pageHeight;
    //
    NSDateComponents *_componentsofTody;
    //当前选中的日期。（滚动scrollView所选中！）
    NSInteger _selectedYear, _selectedMonth;
    //点击具体日期选中！
    NSDate *_selectedDate;
    
    //网络数据处理
    NSMutableDictionary *_requestedMonthRecords;
}

@end

@implementation PMClockinRecordsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"打卡记录";
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setupUI];
    [self setData];
}

- (void)setupUI {
    /************************  header  ***************************/
    //configuration:  注意这里的参数必须与PMMonthView内的一直
    CGFloat sideSpacing = 10;
    CGFloat btnSpacing_hrz = 8;
    CGFloat headerH = 30;
    
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat contentWidth = width - sideSpacing*2;
    CGFloat btnW = (contentWidth - btnSpacing_hrz*6)/7;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, headerH)];
    header.backgroundColor = [UIColor clearColor];
    [self.view addSubview:header];
    NSArray *headerTexts = @[@"日", @"一", @"二", @"三", @"四", @"五", @"六"];
    for (NSInteger i = 0; i < 7; i++) {
        CGFloat labelX = sideSpacing + (btnW + btnSpacing_hrz)*i;
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(labelX, 0, btnW, headerH)];
        headerLabel.font = [UIFont fontWithName:@"Helvetica" size:11];
        headerLabel.textColor = grayColor(250);
        headerLabel.textAlignment = NSTextAlignmentCenter;
        headerLabel.text = headerTexts[i];
        [header addSubview:headerLabel];
    }
    /************************  创建3个日历View  ***************************/
    _monthView1 = [PMMonthView monthView];
    CGRect frame = _monthView1.frame;
    _pageHeight = _monthView1.bounds.size.height;
    header.backgroundColor = _monthView1.backgroundColor;
    
    _monthView2 = [PMMonthView monthView];
    frame.origin.y = _pageHeight*1;
    _monthView2.frame = frame;
    
    _monthView3 = [PMMonthView monthView];
    frame.origin.y = _pageHeight*2;
    _monthView3.frame = frame;
    
    CGFloat scrollViewHeight = _pageHeight;
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, headerH, [UIScreen mainScreen].bounds.size.width, scrollViewHeight)];
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, scrollViewHeight*3);
    _scrollView.pagingEnabled = YES;            //必须设置为YES
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.delegate = self;
    [self.view addSubview:_scrollView];
    
    [_scrollView addSubview:_monthView1];
    [_scrollView addSubview:_monthView2];
    [_scrollView addSubview:_monthView3];
    
    __weak typeof(self) weakSelf = self;
    //理想状态下，只有_monthView2会被点击。因为滚动停止后，_monthView2始终展示在中间。
    _monthView1.didSelectDate = ^(NSDate * _Nonnull selectedDate) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf->_monthView2 clearSelectState];
        [strongSelf->_monthView3 clearSelectState];
        strongSelf->_selectedDate = selectedDate;
        [strongSelf refreshFooterViewData];
    };
    _monthView2.didSelectDate = ^(NSDate * _Nonnull selectedDate) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf->_monthView1 clearSelectState];     //当点击_monthView2中的日期时，另外2个monthView需要清除选中状态。
        [strongSelf->_monthView3 clearSelectState];
        strongSelf->_selectedDate = selectedDate;
        [strongSelf refreshFooterViewData];             //更新底部footerView所选日期打卡详情。
    };
    _monthView3.didSelectDate = ^(NSDate * _Nonnull selectedDate) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf->_monthView1 clearSelectState];
        [strongSelf->_monthView2 clearSelectState];
        strongSelf->_selectedDate = selectedDate;
        [strongSelf refreshFooterViewData];
    };
    //footer view
    CGFloat scrollViewMaxY = _scrollView.frame.origin.y + _scrollView.bounds.size.height;
    _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, scrollViewMaxY, [UIScreen mainScreen].bounds.size.width, 200)];
    [self.view addSubview:_footerView];
    
    _footerContentView = (PMClockinRecordsFooterView *)[[NSBundle mainBundle] loadNibNamed:@"PMClockinRecordsFooterView" owner:nil options:nil].firstObject;
    _footerContentView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 150);
    [_footerView addSubview:_footerContentView];
}

- (void)setData {
    _requestedMonthRecords = [[NSMutableDictionary alloc] init];
    
    _componentsofTody = [JKCalendar getComponentsofDate:[NSDate date]];
    [self setSelectedMonth:_componentsofTody.month year:_componentsofTody.year];
    [_monthView2 tryClickDate:[NSDate date]];
    [_scrollView setContentOffset:CGPointMake(0, _pageHeight)];
    //美化UI--减少日历底部空白
    CGFloat scrollViewMaxY = _scrollView.frame.origin.y + _scrollView.bounds.size.height;
    CGRect frame = self->_footerView.frame;
    frame.origin.y = scrollViewMaxY - self->_monthView2.bottomEmptySpacing;
    self->_footerView.frame = frame;
}

#pragma mark - 年月逻辑
- (void)setSelectedMonth: (NSInteger)month year:(NSInteger) year {
    _selectedYear = year;
    _selectedMonth = month;
    
    _monthView1.selectedDate = _selectedDate;
    _monthView2.selectedDate = _selectedDate;
    _monthView3.selectedDate = _selectedDate;
    //请求网络数据
    [self getNearByMonthsDataforMonth:month year:year];
    
    self.title = [NSString stringWithFormat:@"%zd年%zd月", year, month];
    //选中月份
    [_monthView2 setMonth:_selectedMonth ofYear:_selectedYear];
    NSString *monthKey2 = [self monthKeyForMonth:_selectedMonth year:_selectedYear];
    NSDictionary *clockinInfo2 = _requestedMonthRecords[monthKey2];
    _monthView2.clockinInfo = clockinInfo2;
    //选中月份的上个月
    NSInteger lastMonth = [self lastMonthofReferenceMonth:_selectedMonth];
    NSInteger yearForLastMonth = [self yearForLastMonthofReferenceMonth:_selectedMonth referenceYear:_selectedYear];
    [_monthView1 setMonth:lastMonth ofYear:yearForLastMonth];
    NSString *monthKey1 = [self monthKeyForMonth:lastMonth year:yearForLastMonth];
    NSDictionary *clockinInfo1 = _requestedMonthRecords[monthKey1];
    _monthView1.clockinInfo = clockinInfo1;
    //选中月份的下个月
    NSInteger nextMonth = [self nextMonthofReferenceMonth:_selectedMonth];
    NSInteger yearForNextMonth = [self yearForNextMonthofReferenceMonth:_selectedMonth referenceYear:_selectedYear];
    [_monthView3 setMonth:nextMonth ofYear:yearForNextMonth];
    NSString *monthKey3 = [self monthKeyForMonth:nextMonth year:yearForNextMonth];
    NSDictionary *clockinInfo3 = _requestedMonthRecords[monthKey3];
    _monthView3.clockinInfo = clockinInfo3;
}
//滚动到下个月
- (void)goToNextMonth {
    NSInteger nextMonth = [self nextMonthofReferenceMonth:_selectedMonth];
    NSInteger yearForNextMonth = [self yearForNextMonthofReferenceMonth:_selectedMonth referenceYear:_selectedYear];
    [self setSelectedMonth:nextMonth year:yearForNextMonth];
}
//滚动到上个月
- (void)goBackToLastMonth {
    NSInteger lastMonth = [self lastMonthofReferenceMonth:_selectedMonth];
    NSInteger yearForLastMonth = [self yearForLastMonthofReferenceMonth:_selectedMonth referenceYear:_selectedYear];
    [self setSelectedMonth:lastMonth year:yearForLastMonth];
}

//参考时间的下个月，对应的年份
- (NSInteger)yearForNextMonthofReferenceMonth: (NSInteger)referenceMonth referenceYear: (NSInteger)referenceYear  {
    if (referenceMonth == 12) {
        return referenceYear + 1;
    }
    return referenceYear;
}

- (NSInteger)yearForLastMonthofReferenceMonth: (NSInteger)referenceMonth referenceYear: (NSInteger)referenceYear  {
    if (referenceMonth == 1) {
        return referenceYear - 1;
    }
    return referenceYear;
}

- (NSInteger)nextMonthofReferenceMonth: (NSInteger)referenceMonth {
    if (referenceMonth == 12) {
        return 1;
    }
    return referenceMonth + 1;
}

- (NSInteger)lastMonthofReferenceMonth: (NSInteger)referenceMonth {
    if (referenceMonth == 1) {
        return 12;
    }
    return referenceMonth - 1;
}

- (NSString *)monthKeyForMonth: (NSInteger)month year:(NSInteger) year {
    NSString *monthKey = nil;
    if (month < 10) {
        monthKey = [NSString stringWithFormat:@"%zd-0%zd", year, month];
    }else {
        monthKey = [NSString stringWithFormat:@"%zd-%zd", year, month];
    }
    return monthKey;
}

//因为日期格式为 yyyy-MM-dd，所以当月份、日小于10时，需要在前面补0。
- (NSString *)fullFormatStringForDayOrMonth: (NSInteger) dayorMonth {
    NSString *string = nil;
    if (dayorMonth < 10) {
        string = [NSString stringWithFormat:@"0%zd", dayorMonth];
    }else {
        string = [NSString stringWithFormat:@"%zd", dayorMonth];
    }
    return string;
}

//网络请求得到一个新的数据时，尝试匹配到当前日历；
- (void)trySetRecord:(NSDictionary *)clockinInfo {
    NSString *selectedMonthKey = [self monthKeyForMonth:_selectedMonth year:_selectedYear];
    NSArray *allKeys = [clockinInfo allKeys];
    if (allKeys.count > 0) {
        NSString *akey = allKeys[0];
        if ([akey hasPrefix:selectedMonthKey]) {
            //是属于当前选中月份的数据
            _monthView2.clockinInfo = clockinInfo;
            [_monthView2 tryClickDate:[NSDate date]];
        }
    }
}

#pragma mark - 底部展示打卡信息
- (void)refreshFooterViewData {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM";
    NSString *monthKey = [formatter stringFromDate:_selectedDate];
    NSDictionary *monthRecord = _requestedMonthRecords[monthKey];
    
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *dayString = [formatter stringFromDate:_selectedDate];
    NSDictionary *dayInfo = monthRecord[dayString];
    [_footerContentView setDayInfo:dayInfo dayString:dayString];
}

#pragma mark - request

//一次请求当前展示月份的 前面、后面若干个月的数据。
- (void)getNearByMonthsDataforMonth: (NSInteger) month year: (NSInteger)year {
    [self requestClockinRecordsForMonth:month year:year];
    //往前查两个月！
    NSInteger month_temp1 = [self lastMonthofReferenceMonth:month];
    NSInteger year_temp1 = [self yearForLastMonthofReferenceMonth:month referenceYear:year];
    [self requestClockinRecordsForMonth:month_temp1 year:year_temp1];
    
    NSInteger month_temp2 = [self lastMonthofReferenceMonth:month_temp1];
    NSInteger year_temp2 = [self yearForLastMonthofReferenceMonth:month_temp1 referenceYear:year_temp1];
    [self requestClockinRecordsForMonth:month_temp2 year:year_temp2];
    //往后查一个月
    NSInteger month_temp3 = [self nextMonthofReferenceMonth:month];
    NSInteger year_temp3 = [self yearForNextMonthofReferenceMonth:month referenceYear:year];
    [self requestClockinRecordsForMonth:month_temp3 year:year_temp3];
}

- (void)requestClockinRecordsForMonth: (NSInteger) month year: (NSInteger)year {
    //日期如果比今天还晚，那么肯定没有数据的。
    if (year > _componentsofTody.year) {
        return;
    }
    if (year == _componentsofTody.year && month > _componentsofTody.month) {
        return;
    }
    
    NSString *monthKey = [self monthKeyForMonth:month year:year];
    if (_requestedMonthRecords[monthKey]) {
        return; //已请求或正在请求。防止重复请求，提高性能。
    }
    _requestedMonthRecords[monthKey] = [NSDictionary dictionary];
    NSInteger day0 = random()%28;
    NSString *day0_full = [self fullFormatStringForDayOrMonth:day0];
    NSString *dayKey0 = [monthKey stringByAppendingString:@"-"];
    dayKey0 = [dayKey0 stringByAppendingString:day0_full];
    
    NSString *startClockTime0 = [NSString stringWithFormat:@"%@ 08:04:37", dayKey0];
    NSString *endClockTime0 = [NSString stringWithFormat:@"%@ 18:05:16", dayKey0];
    
    NSInteger day1 = random()%30;
    if (day1 == day0) {
        day1++;
    }
    NSString *day1_full = [self fullFormatStringForDayOrMonth:day1];
    NSString *dayKey1 = [monthKey stringByAppendingString:@"-"];
    dayKey1 = [dayKey1 stringByAppendingString:day1_full];
    
    NSString *startClockTime1 = [NSString stringWithFormat:@"%@ 11:04:37", dayKey1];
    NSString *endClockTime1 = [NSString stringWithFormat:@"%@ 18:05:16", dayKey1];
    
    //startStatus  上班打卡状态，0未打卡1正常2迟到
    //endStatus    下班打卡状态，0未打卡1正常3早退
    //假装忘了请求返回
    NSDictionary *results = @{
                              @"info" : @{
                                      dayKey0 :         @{
                                              @"endClockTime" : endClockTime0,
                                              @"endStatus" : @(1),
                                              @"endTime" : @"16:00:00",
                                              @"endZone" : @(1),
                                              @"startClockTime" : startClockTime0,
                                              @"startStatus" : @(1),
                                              @"startTime" : @"08:00:00",
                                              @"startZone" : @(1),
                                              },
                                      dayKey1 :         @{
                                              @"endClockTime" : endClockTime1,
                                              @"endStatus" : @(3),
                                              @"endTime" : @"21:00:00",
                                              @"endZone" : @(1),
                                              @"startClockTime" : startClockTime1,
                                              @"startStatus" : @(2),
                                              @"startTime" : @"09:00:00",
                                              @"startZone" : @(1),
                                              },
                                      }
                              };
    
    NSDictionary *clockinInfo = results[@"info"];
    if (clockinInfo) {
        self->_requestedMonthRecords[monthKey] = clockinInfo;
        [self trySetRecord:clockinInfo];
    }else {
        [self->_requestedMonthRecords removeObjectForKey:monthKey];
    }
}



#pragma mark - UIScrollViewDelegate
//滚动到底部、顶部之后，给每个日历重新赋值、重新设置setContentOffset使其滚动到中间view；给用户一种幻觉：这个视图是可以无限滚动的。
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y == 0) {
        [self goBackToLastMonth];
        //展示中间的view
        [_scrollView setContentOffset:CGPointMake(0, _pageHeight)];
    }else if (scrollView.contentOffset.y == _pageHeight) {
        //相对来说没滚
    }else {
        [self goToNextMonth];
        //展示中间的view
        [_scrollView setContentOffset:CGPointMake(0, _pageHeight)];
    }
    
    CGFloat scrollViewMaxY = _scrollView.frame.origin.y + _scrollView.bounds.size.height;
    CGRect frame = self->_footerView.frame;
    frame.origin.y = scrollViewMaxY - self->_monthView2.bottomEmptySpacing;
    [UIView animateWithDuration:0.2 animations:^{
        self->_footerView.frame = frame;
    }];
}

@end
