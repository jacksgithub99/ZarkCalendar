

/********************** call me Jack, or Zark *************************/


#import "PMClockinRecordsFooterView.h"

@interface PMClockinRecordsFooterView ()

@property (weak, nonatomic) IBOutlet UILabel *start_time_label;
@property (weak, nonatomic) IBOutlet UILabel *start_title_label;
@property (weak, nonatomic) IBOutlet UILabel *start_subtitle_label;

@property (weak, nonatomic) IBOutlet UILabel *end_time_label;
@property (weak, nonatomic) IBOutlet UILabel *end_title_label;
@property (weak, nonatomic) IBOutlet UILabel *end_subtitle_label;

@property (weak, nonatomic) IBOutlet UIView *noRecordView;


@end

@implementation PMClockinRecordsFooterView

- (void)setDayInfo:(NSDictionary *)dayInfo dayString: (NSString *)dayString {
    if (dayInfo) {
        self.noRecordView.hidden = YES;
        
        //规定的时间
        NSString *should_onduty = dayInfo[@"startTime"];
        NSString *should_offduty = dayInfo[@"endTime"];
        if (should_onduty.length == 5) {
            should_onduty = [should_onduty stringByAppendingString:@":00"];
        }
        if (should_offduty.length == 5) {
            should_offduty = [should_offduty stringByAppendingString:@":00"];
        }
        NSString *timeFormat = @"HH:mm:ss";
        if (should_onduty == nil || should_offduty == nil || should_onduty.length != timeFormat.length || should_offduty.length != timeFormat.length) {
            return;
        }
        //实际打卡时间
        NSString *clockin_onduty = dayInfo[@"startClockTime"];
        NSString *clockin_offduty = dayInfo[@"endClockTime"];
        NSString *dateFormat = @"yyyy-MM-dd HH:mm:ss";
        //打卡状态
        NSNumber *startStatusNum = dayInfo[@"startStatus"];//上班打卡状态，0未打卡1正常2迟到
        NSNumber *endStatusNum = dayInfo[@"endStatus"];//下班打卡状态，0未打卡1正常3早退
//        if (startStatusNum == nil || endStatusNum == nil) {
//            return;
//        }
        NSInteger startStatus = startStatusNum ? [startStatusNum integerValue] : 0;
        NSInteger endStatus = endStatusNum ? [endStatusNum integerValue] : 0;
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = dateFormat;
        NSDate *now = [NSDate date];
        //----------------------------------上班打卡----------------------------------
        self.start_time_label.text = [self getShortTime:should_onduty];
        BOOL isLate = NO;
        NSString *ondutyState = @"正常打卡";
        //上班打卡
        if (startStatus == 0) {//（还）未打卡
            NSString *should_onduty_date_string = [NSString stringWithFormat:@"%@ %@", dayString, should_onduty];
            NSDate *should_onduty_date = [formatter dateFromString:should_onduty_date_string];
            NSTimeInterval interval = [now timeIntervalSinceDate:should_onduty_date];
            if (interval > 0) {
                //已超过时间，但未打卡
                isLate = YES;
                ondutyState = @"未打卡";
            }else {
                ondutyState = @"-----";//还没到上班时间
            }
        }else if (startStatus == 2) {
            //迟到打卡
            isLate = YES;
            ondutyState = @"迟到打卡";
        }
        if (isLate) {
            self.start_title_label.textColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];//redColor
            self.start_subtitle_label.textColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];
        }else {
            self.start_title_label.textColor = [UIColor darkGrayColor];
            self.start_subtitle_label.textColor = [UIColor darkGrayColor];
        }
        NSString *start_time_real = [self getShortTimeForDate:clockin_onduty];
        self.start_subtitle_label.text = [NSString stringWithFormat:@"%@%@", ondutyState, start_time_real];
        //----------------------------------下班打卡----------------------------------
        self.end_time_label.text = [self getShortTime:should_offduty];
        BOOL isOffdutyAbnormal = NO;
        NSString *offdutyState = @"正常打卡";
        if (endStatus == 0) {//（还）未打卡
            NSString *theDay_endSecond_str = [NSString stringWithFormat:@"%@ 23:59:59", dayString];
            NSDate *theDay_endSecond = [formatter dateFromString:theDay_endSecond_str];
            NSTimeInterval interval2 = [now timeIntervalSinceDate:theDay_endSecond];
            if (interval2 > 0) {
                //现在已经超过了打卡日期截止时间，
                isOffdutyAbnormal = YES;
                offdutyState = @"未打卡";
            }else {
                offdutyState = @"-----";//还没到打卡的截止时间
            }
        }else if (endStatus == 3) {
            //早退打卡
            isOffdutyAbnormal = YES;
            offdutyState = @"早退打卡";
        }
        if (isOffdutyAbnormal) {
            self.end_title_label.textColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];//redColor
            self.end_subtitle_label.textColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];
        }else {
            self.end_title_label.textColor = [UIColor darkGrayColor];
            self.end_subtitle_label.textColor = [UIColor darkGrayColor];
        }
        NSString *end_time_real = [self getShortTimeForDate:clockin_offduty];
        self.end_subtitle_label.text = [NSString stringWithFormat:@"%@%@", offdutyState, end_time_real];
    }else {
        self.noRecordView.hidden = NO;
    }
}

//"HH:mm:ss" -> "HH:mm"
- (NSString *)getShortTime: (NSString *)time {
    if (time && time.length >= 5) {
        return [time substringToIndex:5];
    }
    return time;
}
//"yyyy-MM-dd HH:mm:ss" -> "HH:mm"
- (NSString *)getShortTimeForDate: (NSString *)time {
    if (time && time.length == 19) {
        NSString *shortTime = [time substringWithRange:NSMakeRange(11, 5)];
        return [NSString stringWithFormat:@"(%@)", shortTime];
    }
    return @"";
}

@end
