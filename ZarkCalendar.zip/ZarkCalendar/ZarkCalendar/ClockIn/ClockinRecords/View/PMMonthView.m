

/********************** call me Jack, or Zark *************************/

#import "PMMonthView.h"
#import "JKCalendar.h"
#import "JKTools.h"

@interface PMMonthView () {
    UIView *_dayContent_z0;//最底层，_selectedShadow, _todayShowdow
    UIView *_dayContent_z1;//红点
    UIView *_dayContent_z2;//按钮；按钮必须在最上层，才能点击；
    
    UIView *_todayShowdow;//今天 的 按钮阴影
    UIView *_selectedShadow;//选中的日期 的 按钮阴影
    UIButton *_selectedBtn;//选中的日期按钮，指示当前选中的按钮。
    //保存传入的年月
    NSInteger _year;
    NSInteger _month;
    //UI优化：最后一个展示出来的按钮，用于计算显示的最大行数
    NSInteger _showBtnMaxTag;
    CGFloat _showBtnMaxY;
}

@end

@implementation PMMonthView

+ (PMMonthView *)monthView {
    PMMonthView *view = [[PMMonthView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 350)];
    view.backgroundColor = [UIColor colorWithRed:26/255.0 green:133/255.0 blue:248/255.0 alpha:1];
    //蓝-较鲜亮 [UIColor colorWithRed:26/255.0 green:133/255.0 blue:248/255.0 alpha:1]
    return view;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //configuration:
        CGFloat sideSpacing = 10;
        CGFloat btnSpacing_hrz = 8;
        CGFloat btnSpacing_vtc = 8;
        CGFloat headerH = 0;    //header已经移到外部控制器！
        
        CGFloat width = frame.size.width;
        CGFloat contentWidth = width - sideSpacing*2;
        CGFloat btnW = (contentWidth - btnSpacing_hrz*6)/7;
        CGFloat btnH = btnW;//btnH = btnW, round.
        
        CGFloat dayContentH = btnH*6 + btnSpacing_vtc*5;
        /*创建3个图层，从底部到顶部，分别为：
         _dayContent_z0，今天、选中日期的阴影圆圈，_todayShowdow（白色半透明）；_selectedShadow（白色）
         _dayContent_z1，打卡标识的圆点dot；无打卡记录不显示，打卡正常显示淡蓝色圆点（即使与选中的白色阴影重叠，也能看见），打卡异常显示红色圆点。
         _dayContent_z2，按钮图层。必须在最上层，才能被点击。每个按钮显示日期值（1-31）
         */
        _dayContent_z0 = [[UIView alloc] initWithFrame:CGRectMake(sideSpacing, headerH, contentWidth, dayContentH)];
        _dayContent_z0.backgroundColor = [UIColor clearColor];
        [self addSubview:_dayContent_z0];
        
        _dayContent_z1 = [[UIView alloc] initWithFrame:CGRectMake(sideSpacing, headerH, contentWidth, dayContentH)];
        _dayContent_z1.backgroundColor = [UIColor clearColor];
        [self addSubview:_dayContent_z1];
        
        _dayContent_z2 = [[UIView alloc] initWithFrame:CGRectMake(sideSpacing, headerH, contentWidth, dayContentH)];
        _dayContent_z2.backgroundColor = [UIColor clearColor];
        [self addSubview:_dayContent_z2];
        
        _todayShowdow = [[UIView alloc] initWithFrame:CGRectMake(0, 0, btnW, btnH)];  //需要制定选中的日期，才能确定坐标
        _todayShowdow.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0.2];
        _todayShowdow.layer.cornerRadius = btnW/2;
        _todayShowdow.clipsToBounds = YES;
        [_dayContent_z0 addSubview:_todayShowdow];
        _todayShowdow.hidden = YES;
        
        _selectedShadow = [[UIView alloc] initWithFrame:CGRectMake(0, 0, btnW, btnH)];  //需要制定选中的日期，才能确定坐标
        _selectedShadow.backgroundColor = [UIColor whiteColor];
        _selectedShadow.layer.cornerRadius = btnW/2;
        _selectedShadow.clipsToBounds = YES;
        [_dayContent_z0 addSubview:_selectedShadow];
        _selectedShadow.hidden = YES;
        
        /*最多6行，如
            日   一   二   三   四   五   六           <-header
                                        1
            2    3    4    5   6    7   8
            9    10   11   12  13   14  15
            16   17   18   19  20   21  22
            23   24   25   26  27   28  29
            30
            最少4行，平年2月=7*4行 = 28天。
            创建的按钮、圆点数量是固定7*6=42个，只是根据具体月份的日期偏移赋值，隐藏不需要的按钮。
            今天阴影和选中日期阴影分别只有一个view，只是根据数据修改坐标。
         */
        CGFloat dotW = 6;
        CGFloat dot_x_offset = (btnW - dotW)/2;
        CGFloat assume_text_height = 14;//估计的btn文字高度
        CGFloat dot_y_offset = (btnH - assume_text_height)/2 + assume_text_height + 3;
        
        for (NSInteger i = 0; i < 42; i++) {
            NSInteger row = i/7;
            NSInteger index = i%7;
            CGFloat btnX = (btnW + btnSpacing_hrz)*index;
            CGFloat btnY = (btnH + btnSpacing_vtc)*row;
            //创建按钮
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
            btn.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:13];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor purpleColor] forState:UIControlStateSelected];
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            btn.tag = i;
            [_dayContent_z2 addSubview:btn];
            
            CGFloat dotX = btnX + dot_x_offset;
            CGFloat dotY = btnY + dot_y_offset;
            //创建圆点
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(dotX, dotY, dotW, dotW)];
            dot.layer.cornerRadius = dotW/2;
            dot.clipsToBounds = YES;
            dot.tag = i;
            [_dayContent_z1 addSubview:dot];
        }
        //
        self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, headerH + dayContentH + 10);
    }
    return self;
}

//设置当前月份的基础数据，赋值后得到一个基本的日历。只是缺少打卡记录标识。
- (void)setMonth: (NSInteger)month ofYear: (NSInteger)year {
    if (month < 1 || month > 12) {
        return;
    }
    if (year < 1000 || year > 9999) {
        return;
    }
    _year = year;
    _month = month;
    
    _selectedBtn.selected = NO;
    _selectedShadow.hidden = YES;
    
    //***************************计算本月天数、第一天起始位置**********************//
    NSInteger days = [JKCalendar monthDaysofMonth:month year:year];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *month_full = [self fullFormatStringForDayOrMonth:month];
    NSString *firstDayString = [NSString stringWithFormat:@"%zd-%@-01", year, month_full];
    NSDate *firstDayofMonth = [formatter dateFromString:firstDayString];
    NSDateComponents *components = [JKCalendar getComponentsofDate:firstDayofMonth];
    //星期天的weakday = 1, 星期一的weakday = 2..
    NSInteger firstday_s_weakday = components.weekday;
    NSInteger weakday_offset = firstday_s_weakday - 1;
    
    //***************************today showdow  判断今天是不是存在于 显示出来的这个月里面。**********************//
    NSDate *today = [NSDate date];
    NSDateComponents *today_components = [JKCalendar getComponentsofDate:today];
    BOOL isCuttentMonth = NO;
    if (today_components.year == components.year && today_components.month == components.month) {
        //今天包含在（当前显示的）‘这个月’里面
        isCuttentMonth = YES;
    }else {
        isCuttentMonth = NO;
    }
    _todayShowdow.hidden = !isCuttentMonth;
    //***************************计算当前选中日期参数**********************//
    NSDateComponents *selecteddate_components = [JKCalendar getComponentsofDate:_selectedDate];
    BOOL isSelectedDateInThisMonth = NO;
    if (selecteddate_components) {
        isSelectedDateInThisMonth = (selecteddate_components.year == year && selecteddate_components.month == month);
    }
    
    _showBtnMaxTag = 0;
    _showBtnMaxY = 60;  //随便给个初始值
    for (UIButton *btn in _dayContent_z2.subviews) {
        if (btn.tag < weakday_offset || btn.tag >= days + weakday_offset) {
            //隐藏
            btn.hidden = YES;
        }else {
            //显示存在的日期
            btn.hidden = NO;
            NSInteger day = btn.tag - weakday_offset + 1;
            [btn setTitle:[NSString stringWithFormat:@"%zd", day] forState:UIControlStateNormal];
            //日期是否是今天
            if (isCuttentMonth) {
                if (day == today_components.day) {
                    //如果是今天，则在日期上 加阴影。
                    _todayShowdow.frame = btn.frame;
                }
            }
            //是否是选中的日期
            if (isSelectedDateInThisMonth) {
                if (day == selecteddate_components.day) {
                    //如果是选中的日期，则在日期上 加阴影。
                    btn.selected = YES;
                    _selectedBtn = btn;
                    _selectedShadow.hidden = NO;
                    _selectedShadow.frame = btn.frame;
                }
            }
            //
            if (btn.tag > _showBtnMaxTag) {
                _showBtnMaxTag = btn.tag;
                _showBtnMaxY = btn.frame.origin.y + btn.frame.size.height;
            }
        }
    }
}

//标识打卡信息（某个日期有打卡记录，则显示圆点；打卡异常显示红点，打卡正常显示浅蓝圆点；无打卡记录则隐藏圆点。）
- (void)setClockinInfo:(NSDictionary *)clockinInfo {
    _clockinInfo = clockinInfo;
    
    NSInteger year = _year;
    NSInteger month = _month;
    //***************************计算本月天数、第一天起始位置**********************//
    NSInteger days = [JKCalendar monthDaysofMonth:month year:year];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *month_full = [self fullFormatStringForDayOrMonth:month];
    NSString *firstDayString = [NSString stringWithFormat:@"%zd-%@-01", year, month_full];
    NSDate *firstDayofMonth = [formatter dateFromString:firstDayString];
    NSDateComponents *components = [JKCalendar getComponentsofDate:firstDayofMonth];
    //星期天的weakday = 1, 星期一的weakday = 2..
    NSInteger firstday_s_weakday = components.weekday;
    NSInteger weakday_offset = firstday_s_weakday - 1;
    
    //***************************计算当前选中日期参数**********************//
    for (UIView *dot in _dayContent_z1.subviews) {
        if (dot.tag < weakday_offset || dot.tag >= days + weakday_offset) {
            //隐藏
            dot.hidden = YES;
        }else {
            //显示存在的日期
            NSInteger day = dot.tag - weakday_offset + 1;
            NSString *day_full = [self fullFormatStringForDayOrMonth:day];
            NSString *dayString = [NSString stringWithFormat:@"%zd-%@-%@", year, month_full, day_full];
            NSDictionary *dayInfo = clockinInfo[dayString];
            if (dayInfo) {//有打卡记录
                dot.hidden = NO;
                if ([self isClockinNormal:dayInfo day:dayString]) {
                    dot.backgroundColor = [UIColor colorWithRed:0.7 green:0.9 blue:1 alpha:0.6];
                }else {
                    dot.backgroundColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];//redColor
                }
            }else {
                dot.hidden = YES;
            }
        }
    }
}

//判断打卡是否正常（如果没打卡，则dayInfo不包含日期信息；所以需要传dayString）
//需要根据数据格式，自定义内部的判断逻辑。
- (BOOL)isClockinNormal: (NSDictionary *)dayInfo day: (NSString *)dayString {
    //规定的时间
    NSString *should_onduty = dayInfo[@"startTime"];
    NSString *should_offduty = dayInfo[@"endTime"];
    NSString *timeFormat = @"HH:mm:ss";
    if (should_onduty.length == 5) {
        should_onduty = [should_onduty stringByAppendingString:@":00"];
    }
    if (should_offduty.length == 5) {
        should_offduty = [should_offduty stringByAppendingString:@":00"];
    }
    if (should_onduty == nil || should_offduty == nil || should_onduty.length != timeFormat.length || should_offduty.length != timeFormat.length) {
        return NO;
    }
    //实际打卡时间
    NSString *dateFormat = @"yyyy-MM-dd HH:mm:ss";
    //打卡状态
    NSNumber *startStatusNum = dayInfo[@"startStatus"];//上班打卡状态，0未打卡1正常2迟到
    NSNumber *endStatusNum = dayInfo[@"endStatus"];//下班打卡状态，0未打卡1正常3早退
    if (startStatusNum == nil || endStatusNum == nil) {
        return NO;
    }
    NSInteger startStatus = [startStatusNum integerValue];
    NSInteger endStatus = [endStatusNum integerValue];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = dateFormat;
    NSDate *now = [NSDate date];
    //上班打卡
    if (startStatus == 0) {//（还）未打卡
        NSString *should_onduty_date_string = [NSString stringWithFormat:@"%@ %@", dayString, should_onduty];
        NSDate *should_onduty_date = [formatter dateFromString:should_onduty_date_string];
        NSTimeInterval interval = [now timeIntervalSinceDate:should_onduty_date];
        if (interval > 0) {
            //已超过时间，但未打卡
            return NO;
        }
    }else if (startStatus == 2) {
        //迟到打卡
        return NO;
    }
    //下班打卡
    if (endStatus == 0) {//（还）未打卡
        NSString *theDay_endSecond_str = [NSString stringWithFormat:@"%@ 23:59:59", dayString];
        NSDate *theDay_endSecond = [formatter dateFromString:theDay_endSecond_str];
        NSTimeInterval interval2 = [now timeIntervalSinceDate:theDay_endSecond];
        if (interval2 > 0) {
            //现在已经超过了打卡日期截止时间，
            return NO;
        }
    }else if (startStatus == 3) {
        //早退打卡
        return NO;
    }
    return YES;
}

//如果之前被选中了，清除选中状态。
- (void)clearSelectState {
    if (_selectedBtn) {
        _selectedBtn.selected = NO;
        _selectedShadow.hidden = YES;
        _selectedDate = nil;
    }
}

//因为日期格式为 yyyy-MM-dd，所以当月份、日小于10时，需要在前面补0。
- (NSString *)fullFormatStringForDayOrMonth: (NSInteger) dayorMonth {
    NSString *string = nil;
    if (dayorMonth < 10) {
        string = [NSString stringWithFormat:@"0%zd", dayorMonth];
    }else {
        string = [NSString stringWithFormat:@"%zd", dayorMonth];
    }
    return string;
}
//当前月份所需要的最大行数。（未用到）
- (NSInteger)maxRowCount {
    return ceil((_showBtnMaxTag + 1)/7.0);
}
//当前月份，最后一行最后一个按钮，距离底部的空白距离。多留10个点，其他空白，在外部用其他视图遮起来。
- (CGFloat)bottomEmptySpacing {
    return self.bounds.size.height - _showBtnMaxY - 10;
}

//初始化时需要选中当前日期。如果当前日期包含在本月，则点击它。
- (void)tryClickDate: (NSDate *)date {
    NSDateComponents *components = [JKCalendar getComponentsofDate:date];
    if (components.year == _year && components.month == _month) {
        for (UIButton *btn in _dayContent_z2.subviews) {
            NSString *btnDay = [btn titleForState:UIControlStateNormal];
            if ([btnDay integerValue] == components.day) {
                [self btnClick:btn];
                break;
            }
        }
    }
}

//点击某个日期，移动选中阴影_selectedShadow到该按钮处。
- (void)btnClick: (UIButton *)btn {
    [self clearSelectState];
    btn.selected = YES;
    _selectedBtn = btn;
    
    _selectedShadow.hidden = NO;
    _selectedShadow.frame = btn.frame;
    //回调方法
    if (self.didSelectDate != nil) {
        NSString *dayString = [btn titleForState:UIControlStateNormal];
        NSCalendar *canlendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        //根据传入的年月，以及按钮title显示的日期，合成一个完整的日期。
        components.year = _year;
        components.month = _month;
        components.day = [dayString integerValue];
        NSDate *selectedDate = [canlendar dateFromComponents:components];
        self.didSelectDate(selectedDate);
    }
}

@end
