

/********************** call me Jack, or Zark *************************/




/*
                                        警告，
                        以下2个方法包含了打卡记录格式，需要自己根据数据格式修改。
                        其主要功能是判断指定日期是否包含打卡记录、打卡是否正常。
 - (void)setClockinInfo:(NSDictionary *)clockinInfo
 - (BOOL)isClockinNormal: (NSDictionary *)dayInfo day: (NSString *)dayString
 */

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PMMonthView : UIView
//快捷构造方法
+ (PMMonthView *)monthView;


//全局对象，其他PMMonthView共用（同步）；当前月份未必包含selectedDate
@property(nonatomic, strong) NSDate *selectedDate;
//点击日期后回调
@property(nonatomic, copy) void (^didSelectDate) (NSDate *selectedDate);
//本月打卡信息
@property(nonatomic, strong) NSDictionary *clockinInfo;

- (void)setMonth: (NSInteger)month ofYear: (NSInteger)year;
//如果之前被选中了，清除选中状态。
- (void)clearSelectState;
//初始化时需要选中当前日期。如果当前日期包含在本月，则点击它。
- (void)tryClickDate: (NSDate *)date;

/*日历底部空白高度。
 这个日历控件高度是固定的（因为在scrollView内有3个控件，pageEnable = YES；所以必须每个page高度一致；3个控件‘循环’滚动，让人感觉有无限个日历视图可以翻阅），
 固定有6行按钮。但是每个月所需要显示的行数是不固定的4-6行。
 这个方法返回具体月份下，底部有多少空白。
 scroll滚定停止后，重新给日历赋值（setMonth:ofYear:），赋值后可获取底部空白高度。
 可在外部根据需要进行遮挡底部空白，比如把下方的打卡详细信息上移bottomEmptySpacing个点。
 */
- (CGFloat)bottomEmptySpacing;

@end

NS_ASSUME_NONNULL_END
