

/********************** call me Jack, or Zark *************************/


#import "PMClockInViewController.h"
#import "TheMarcro.h"

#import "JKTools.h"
#import "PMClockinRecordsViewController.h"

@interface PMClockInViewController () {
    NSTimer *_timer;
    NSTimeInterval _timerInterval;
    
    NSDictionary *_gotInfo;
    NSTimeInterval _intervalSinceGotInfo;
    
    NSDate *_lastGetInfoDate;
    //打卡记录用到
    id _parkingLotId;
}
//打卡前
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UIImageView *some_icon;
@property (weak, nonatomic) IBOutlet UILabel *condition_text_label;
@property (weak, nonatomic) IBOutlet UILabel *location_label;

@property (weak, nonatomic) IBOutlet UIView *rounded_clock;
@property (weak, nonatomic) IBOutlet UILabel *time_label;
@property (weak, nonatomic) IBOutlet UILabel *event_label;
@property (weak, nonatomic) IBOutlet UIButton *clock_in_btn;

@property (weak, nonatomic) IBOutlet UILabel *reminder_label;
//打卡后
@property (weak, nonatomic) IBOutlet UIView *contentView2;
@property (weak, nonatomic) IBOutlet UIImageView *clock_in_result_icon;
@property (weak, nonatomic) IBOutlet UILabel *operation_result_label;
@property (weak, nonatomic) IBOutlet UILabel *remark_label;
@property (weak, nonatomic) IBOutlet UILabel *clockin_time_label;
@property (weak, nonatomic) IBOutlet UILabel *clockin_location_label;

@property (weak, nonatomic) IBOutlet UIButton *reclockin_btn;

@end

@implementation PMClockInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"打卡上班";
    
    [self setupUI];
    [self setData];
}

- (void)setupUI {
    self.view.backgroundColor = [UIColor colorWithWhite:247.0 / 255.0 alpha:1];
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"打卡记录" style:UIBarButtonItemStylePlain target:self action:@selector(rightItemClick:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    //
    self.contentView.layer.borderWidth = 1;
    self.contentView.layer.borderColor = grayColor(240).CGColor;
    self.contentView.layer.shadowOffset = CGSizeMake(0, 0);
    self.contentView.layer.shadowColor = grayColor(250).CGColor;//
    self.contentView.layer.shadowOpacity = 1;
    
    self.rounded_clock.backgroundColor = [UIColor whiteColor];
    self.rounded_clock.layer.cornerRadius = 70;
    self.rounded_clock.layer.borderWidth = 8;
    self.rounded_clock.layer.borderColor = [UIColor colorWithRed:254/255.0 green:203/255.0 blue:61/255.0 alpha:0.5].CGColor;
    self.rounded_clock.clipsToBounds = YES;
    self.clock_in_btn.enabled = NO;     //获取到打卡信息才允许打卡
    
    self.contentView.hidden = NO;
    self.contentView2.hidden = YES;
    
    self.reminder_label.text = @"Greetings!O(∩_∩)O~";
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [_timer invalidate];
    _timer = nil;
    
}

- (void)setData {
    _timerInterval = 10;
    _intervalSinceGotInfo = 0;
    _timer = [NSTimer scheduledTimerWithTimeInterval:_timerInterval target:self selector:@selector(timerTick) userInfo:nil repeats:YES];
    [_timer fire];
    
    [self requestGetClockinInfo: NO];
}

#pragma mark - touch event
- (void)rightItemClick: (id)sender {
    PMClockinRecordsViewController *vc = [[PMClockinRecordsViewController alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)clock_in_btn_click:(id)sender {
    _lastGetInfoDate = nil;//开门
    [self requestGetClockinInfo:YES];
}

- (IBAction)reclockin_btn_click:(id)sender {
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"更新打卡时间？" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        self->_lastGetInfoDate = nil;//开门
        [self requestGetClockinInfo:YES];
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [vc addAction:ok];
    [vc addAction:cancel];
    [self presentViewController:vc animated:YES completion:nil];
}
#pragma mark - timer tick
- (void)timerTick {
    NSString *systemTime = _gotInfo[@"sysFullTime"];
    NSDate *systemDate = [JKTools dateFromString:systemTime format:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *currentDate = nil;
    if (systemDate) {
        currentDate = [NSDate dateWithTimeInterval:_intervalSinceGotInfo sinceDate:systemDate];
    }
    _intervalSinceGotInfo += _timerInterval;
    if (!currentDate) {
        currentDate = [NSDate date];
    }
    NSString *timeString = [JKTools stringFromDate:currentDate format:@"HH:mm"];
    self.time_label.text = timeString;
}

#pragma mark - task
//打卡之后
- (void)refreshOperationResultUI {
    self.contentView.hidden = YES;
    self.contentView2.hidden = NO;
    NSString *result_str = [self getOperationDescription];
    self.operation_result_label.text = result_str;
    if ([result_str rangeOfString:@"正常"].location != NSNotFound) {
        self.clock_in_result_icon.image = [UIImage imageNamed:@"clockin_ok_icon"];
        self.operation_result_label.textColor = [UIColor colorWithRed:26/255.0 green:152/255.0 blue:86/255.0 alpha:1];//green
        self.remark_label.textColor = [UIColor colorWithRed:26/255.0 green:152/255.0 blue:86/255.0 alpha:1];//green
    }else {
        self.clock_in_result_icon.image = [UIImage imageNamed:@"clockin_abnormal_icon"];
        self.operation_result_label.textColor = [UIColor colorWithRed:251/255.0 green:69/255.0 blue:59/255.0 alpha:1];//red
        self.remark_label.textColor = [UIColor grayColor];
    }
    
    NSString *systemTime = _gotInfo[@"sysFullTime"];
    NSDate *systemDate = [JKTools dateFromString:systemTime format:@"yyyy-MM-dd HH:mm:ss"];
    if (systemDate) {
        self.clockin_time_label.text = [JKTools stringFromDate:systemDate format:@"HH:mm"];
    }else {
        self.clockin_time_label.text = @"-";
    }
    
    NSInteger currentType = [self->_gotInfo[@"type"] integerValue];
    NSString *clockinKey = [PMClockInViewController getClockinKey];
    BOOL isOnduty = NO;
    if (currentType == 0) {
        //上班打卡
        self.remark_label.text = @"上班打卡成功";
        self.reclockin_btn.hidden = YES;
        isOnduty = YES;
    }else {
        //下班打卡
        self.remark_label.text = @"今日打卡已完成";
        self.reclockin_btn.hidden = YES;//不允许二次打卡！！！
    }
    NSString *value = [PMClockInViewController todyClockinValue:isOnduty];
    [[NSUserDefaults standardUserDefaults] setValue:value forKey:clockinKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSInteger zone = [self->_gotInfo[@"zone"] integerValue];
    if (zone == 0) {
        self.clockin_location_label.text = @"未在打卡范围";
    }else {
        self.clockin_location_label.text = @"打卡范围";
    }
}

- (NSString *)getOperationDescription {
    NSInteger currentType = [self->_gotInfo[@"type"] integerValue];
    NSString *operation = @"";
    NSString *timeJudge = @"";
    BOOL clockinAbnormal = NO;
    //系统时间
    NSString *systemTime = _gotInfo[@"sysFullTime"];
    NSDate *systemDate = [JKTools dateFromString:systemTime format:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *currentDate = nil;
    if (systemDate) {
        currentDate = [NSDate dateWithTimeInterval:_intervalSinceGotInfo sinceDate:systemDate];
    }
    
    if (currentType == 0) {
        //上班打卡
        operation = @"上班";
        NSString *startTime = _gotInfo[@"startTime"];
        if (currentDate && startTime && startTime.length == 8) {
            NSString *currentDateString = [JKTools stringFromDate:currentDate format:@"yyyy-MM-dd"];
            NSString *work_begin_time = [NSString stringWithFormat:@"%@ %@", currentDateString, startTime];
            NSDate *work_begin_date = [JKTools dateFromString:work_begin_time format:@"yyyy-MM-dd HH:mm:ss"];
            NSTimeInterval intervalSinceOnwork = [currentDate timeIntervalSinceDate:work_begin_date];
            if (intervalSinceOnwork > 0) {
                //迟到
                timeJudge = @"·迟到";
                clockinAbnormal = YES;
            }
        }
    }else {
        //下班打卡
        operation = @"下班";
        NSString *endTime = _gotInfo[@"endTime"];
        if (currentDate && endTime && endTime.length == 8) {
            NSString *currentDateString = [JKTools stringFromDate:currentDate format:@"yyyy-MM-dd"];
            NSString *off_duty_time = [NSString stringWithFormat:@"%@ %@", currentDateString, endTime];
            NSDate *off_duty_date = [JKTools dateFromString:off_duty_time format:@"yyyy-MM-dd HH:mm:ss"];
            NSTimeInterval intervalSinceOffduty = [currentDate timeIntervalSinceDate:off_duty_date];
            if (intervalSinceOffduty < 0) {
                //早退
                timeJudge = @"·早退";
                clockinAbnormal = YES;
            }
        }
    }
    NSInteger zone = [self->_gotInfo[@"zone"] integerValue];
    NSString *insideZone = @"";
    if (zone == 0) {
        insideZone = @"·不在打卡范围";
        clockinAbnormal = YES;
    }
    NSString *okString = clockinAbnormal ? @"" : @"·正常";
    
    return [NSString stringWithFormat:@"%@%@%@%@", operation, okString, insideZone, timeJudge];
}

#pragma mark - request
- (void)requestClockin {
    //假装网络请求成功，返回
    [self refreshOperationResultUI];
}

//获取打卡信息
- (void)requestGetClockinInfo: (BOOL)clockinAfterSuccuss {
    
    if (_lastGetInfoDate) {
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:_lastGetInfoDate];
        if (interval < 20) {
            return;//防止频繁请求；
        }
    }
    _lastGetInfoDate = [NSDate date];
    
    //假装网络请求
     NSDictionary *results = @{
                       @"endTime" : @"22:00:00",
                       @"inDistance" : @(0),
                       @"lastStatus" : @(3),
                       @"lastTime" : @"17:29:39",
                       @"lastType" : @(1),
                       @"lastZone" : @(1),
                       @"lat" : @"22.52239",
                       @"lng" : @"113.938684",
                       @"parkingLotId" : @(17),
                       @"parkingLotName" : @"xxx停车场",
                       @"sessionId" : @"d82f5a44-b2bf-41d1-ae92-6be3795272bb",
                       @"startTime" : @"07:00:00",
                       @"status" : @(3),
                       @"sysFullTime" : @"2019-07-05 21:07:43",
                       @"sysTime" : @"21:07",
                       @"type" : @(1),
                       @"update" : @(1),
                       @"zone" : @(1)
    };
    self->_gotInfo = results;
    self->_intervalSinceGotInfo = 0;
    self->_parkingLotId = results[@"parkingLotId"];
    if ([results[@"update"] boolValue]) {
        //已打下班卡
        [self refreshOperationResultUI];
    }else {
        self.contentView.hidden = NO;
        self.contentView2.hidden = YES;
        if ([results[@"zone"] boolValue]) {
            self.condition_text_label.text = @"您已在打卡范围内";
        }else {
            self.condition_text_label.text = @"您不在打卡范围内";
        }
        self.location_label.text = results[@"parkingLotName"];
        if ([results[@"type"] integerValue] == 0) {
            self.event_label.text = @"上班打卡";
            self.reminder_label.text = [NSString stringWithFormat:@"请在%@之前打卡", results[@"startTime"]];
        }else {
            self.event_label.text = @"下班打卡";
            self.reminder_label.text = [NSString stringWithFormat:@"请在%@之后打卡", results[@"endTime"]];
            
            NSString *clockinKey = [PMClockInViewController getClockinKey];
            NSString *value = [PMClockInViewController todyClockinValue:YES];   //已经打了上班卡
            [[NSUserDefaults standardUserDefaults] setValue:value forKey:clockinKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        self.rounded_clock.layer.borderColor = [UIColor colorWithRed:254/255.0 green:203/255.0 blue:61/255.0 alpha:1].CGColor;
        self.clock_in_btn.enabled = YES;
    }
    if (clockinAfterSuccuss) {
        [self requestClockin];  //打卡
    }
}

#pragma mark -
//上、下班打卡key
+ (NSString *)getClockinKey {
    NSString *userId = @"s89038195jkfajo";
    NSString *clockinKey = [NSString stringWithFormat:@"Clockin_%@", userId];
    return clockinKey;
}

+ (NSString *)todyClockinValue: (BOOL)isOnDuty {
    NSString *clockinValue = @"";
    NSString *dateString = [JKTools stringFromDate:[NSDate date] format:@"yyyy_MM_dd"];
    if (isOnDuty) {//上班打卡
        clockinValue = [NSString stringWithFormat:@"OnDuty_%@", dateString];
    }else {//下班打卡
        clockinValue = [NSString stringWithFormat:@"OffDuty_%@", dateString];
    }
    return clockinValue;
}

@end
