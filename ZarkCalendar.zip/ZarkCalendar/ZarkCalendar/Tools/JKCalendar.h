
/********************** call me Jack, or Zark *************************/


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JKCalendar : NSObject

//计算一个月里面总共有多少天。
+ (NSInteger)monthDaysofMonth: (NSInteger)month year: (NSInteger)year ;
//获取日期的组件年、月、日、星期值weekday等。
+ (NSDateComponents *)getComponentsofDate: (NSDate *)date;

@end

NS_ASSUME_NONNULL_END
