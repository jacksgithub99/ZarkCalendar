
/********************** call me Jack, or Zark *************************/

#import "JKCalendar.h"

@implementation JKCalendar

+ (NSInteger)monthDaysofDate: (NSDate *)date {
//    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSCalendar *canlendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSInteger month = [canlendar component:NSCalendarUnitMonth fromDate:date];
    NSInteger year = [canlendar component:NSCalendarUnitYear fromDate:date];
    return [JKCalendar monthDaysofMonth:month year:year];
}

+ (NSInteger)monthDaysofMonth: (NSInteger)month year: (NSInteger)year {
    if (month < 1 || month > 12) {
        return 0;
    }
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
        return 31;
    }else if (month == 4 || month == 6 || month == 9 || month == 11){
        return 30;
    }else {
        //month == 2
        return [JKCalendar isLeapYear:year] ? 29 : 28;
    }
}

//闰年的计算，归结起来就是通常说的：四年一闰；百年不闰，四百年再闰。
+ (NSInteger)isLeapYear: (NSInteger)year {
    if ((year%100) == 0) {
        //整百 年
        return ((year%400) == 0);
    }else {
        //普通年份
        return ((year%4) == 0);
    }
}

//星期天的weakday = 1, 星期一的weakday = 2..
+ (NSDateComponents *)getComponentsofDate: (NSDate *)date {
    if (date == nil) {
        return nil;
    }
    NSCalendar *canlendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *components = [canlendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday fromDate:date];
    return components;
}

@end
