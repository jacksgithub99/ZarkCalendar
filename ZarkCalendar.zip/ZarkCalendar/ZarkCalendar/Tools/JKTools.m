
/********************** call me Jack, or Zark *************************/

#import "JKTools.h"

@implementation JKTools

+ (NSString *)encodeUrlStringWith: (NSString *)originalUrlString {
    NSString *encodedUrlStr = [originalUrlString stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    return encodedUrlStr;
}

+ (NSString *)stringFromDate:(NSDate *)date format:(NSString *)format {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = format;
    
    NSString *dateString = [dateFormatter stringFromDate:date];
    return dateString;
}

+ (NSDate *)dateFromString: (NSString *)dateString format: (NSString *)format {
    if (dateString == nil || format == nil) {
        return nil;
    }
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    dateformat.dateFormat = format;
    dateformat.calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSDate *date = [dateformat dateFromString:dateString];
    return date;
}

//返回一个日期，设置时间为00:00:00 000
+ (NSDate *)dateBeginofDate:(NSDate *)date {
    
    NSString *dateString = [JKTools stringFromDate:date format:@"yyyy-MM-dd"];
    NSString *dateZeroString = [dateString stringByAppendingString:@" 00:00:00 000"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss SSS";
    
    NSDate *dateBegin = [dateFormatter dateFromString:dateZeroString];
    return dateBegin;
}

//返回一个日期，设置时间为23:59:59 999
+ (NSDate *)dateEndofDate:(NSDate *)date {
    
    NSString *dateString = [JKTools stringFromDate:date format:@"yyyy-MM-dd"];
    NSString *dateEndString = [dateString stringByAppendingString:@" 23:59:59 999"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss SSS";
    
    NSDate *dateEnd = [dateFormatter dateFromString:dateEndString];
    return dateEnd;
}

//仅比较 日期部分！不在乎 时分秒是否一致！
+ (BOOL)isSameDate:(NSDate *)firstDate secondDate:(NSDate *)secondDate {
    
    NSString *firstDateString = [JKTools stringFromDate:firstDate format:@"yyyy-MM-dd"];
    NSString *secondDateString = [JKTools stringFromDate:secondDate format:@"yyyy-MM-dd"];
    return [firstDateString isEqualToString:secondDateString];
}

+ (UIColor *)colorWithHex:(NSString *)hexStr {
    NSString *format = @"^([0-9]|[a-fA-F]){6}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",format];
    if (![predicate evaluateWithObject:hexStr]) {
        return [UIColor clearColor];
    }
    NSString *valueStr1 = [hexStr substringToIndex:2];
    NSString *valueStr2 = [hexStr substringWithRange:NSMakeRange(2, 2)];
    NSString *valueStr3 = [hexStr substringFromIndex:4];
    
    NSInteger value1 = [JKTools valueofOneByteHex:valueStr1];
    NSInteger value2 = [JKTools valueofOneByteHex:valueStr2];
    NSInteger value3 = [JKTools valueofOneByteHex:valueStr3];
    
    UIColor *color = [UIColor colorWithRed:value1/255.f green:value2/255.f blue:value3/255.f alpha:1.f];
    return color;
}

+ (NSInteger)valueofOneByteHex:(NSString *)hexStr {
    NSString *format = @"^([0-9]|[a-fA-F]){2}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",format];
    if (![predicate evaluateWithObject:hexStr]) {
        return 0;
    }
    NSString *firstChar = [hexStr substringToIndex:1];// not containing index 1
    NSString *secondChar = [hexStr substringFromIndex:1]; //containing index 1
    
    NSInteger heighValue = [JKTools valueofHexChar:firstChar];
    NSInteger lowValue = [JKTools valueofHexChar:secondChar];
    NSInteger value = heighValue*16 + lowValue;
    return value;
}

+ (NSInteger)valueofHexChar:(NSString *)hexChar {
    NSInteger value = 0;
    if ([hexChar isEqualToString:@"a"] || [hexChar isEqualToString:@"A"]) {
        value = 10;
    }else if ([hexChar isEqualToString:@"b"] || [hexChar isEqualToString:@"B"]) {
        value = 11;
    }else if ([hexChar isEqualToString:@"c"] || [hexChar isEqualToString:@"C"]) {
        value = 12;
    }else if ([hexChar isEqualToString:@"d"] || [hexChar isEqualToString:@"D"]) {
        value = 13;
    }else if ([hexChar isEqualToString:@"e"] || [hexChar isEqualToString:@"E"]) {
        value = 14;
    }else if ([hexChar isEqualToString:@"f"] || [hexChar isEqualToString:@"F"]) {
        value = 15;
    }else {
        value = [hexChar integerValue];
    }
    return value;
}

+ (NSString *)stringofFloat:(NSNumber *)number maxFractionDigits:(NSInteger)maxFDs {
    NSNumberFormatter *numFormatter = [[NSNumberFormatter alloc] init];
    numFormatter.numberStyle = NSNumberFormatterDecimalStyle;
    numFormatter.minimumIntegerDigits = 1;
    numFormatter.maximumFractionDigits = maxFDs;
    return [numFormatter stringFromNumber:number];
}

+ (CGFloat)heightForText:(NSString *)text width:(CGFloat)width font:(UIFont *)font{
    if (text == nil || width < 0 || font == nil) {
        return 0;
    }
    CGFloat height = [text boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil].size.height;
    return height;
}

+ (NSString *)cutoffZerosFor:(CGFloat)value byLeaving: (NSInteger)maximumFractionDigits {
    
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.minimumIntegerDigits = 1;
    formatter.maximumFractionDigits = maximumFractionDigits;
    
    return [formatter stringFromNumber:[NSNumber numberWithFloat:value]];
}

+ (BOOL)isMadeofNumberLetter:(NSString *)string {
    if (!string) {
        return NO;
    }
    NSString *format = @"^[0-9]?$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",format];
    return [predicate evaluateWithObject:string];
}

@end
