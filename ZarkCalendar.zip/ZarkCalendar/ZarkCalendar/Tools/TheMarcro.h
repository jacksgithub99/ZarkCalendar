

/********************** call me Jack, or Zark *************************/

#import <Foundation/Foundation.h>

#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#define grayColor(x) [UIColor colorWithRed:x/255.0 green:x/255.0 blue:x/255.0 alpha:1]
