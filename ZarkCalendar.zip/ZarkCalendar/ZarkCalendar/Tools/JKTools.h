
/********************** call me Jack, or Zark *************************/

#import <UIKit/UIKit.h>

@interface JKTools : NSObject

+ (NSString *)encodeUrlStringWith: (NSString *)originalUrlString;

+ (NSString *)stringFromDate:(NSDate *)date format:(NSString *)format;

+ (NSDate *)dateFromString: (NSString *)dateString format: (NSString *)format;

//返回一个日期，设置时间为00:00:00
+ (NSDate *)dateBeginofDate:(NSDate *)date;

//返回一个日期，设置时间为23:59:59 999
+ (NSDate *)dateEndofDate:(NSDate *)date;

//仅比较 日期部分！不在乎 时分秒是否一致！
+ (BOOL)isSameDate:(NSDate *)firstDate secondDate:(NSDate *)secondDate;

//format @"001aFB"
+ (UIColor *)colorWithHex:(NSString *)hexStr;

+ (NSString *)stringofFloat:(NSNumber *)number maxFractionDigits:(NSInteger)maxFDs;

+ (CGFloat)heightForText:(NSString *)text width:(CGFloat)width font:(UIFont *)font;

+ (NSString *)cutoffZerosFor:(CGFloat)value byLeaving: (NSInteger)maximumFractionDigits;

+ (BOOL)isMadeofNumberLetter:(NSString *)string;

@end
